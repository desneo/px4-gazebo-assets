#include <cmath>
#include <cstdint>
#include <cstddef>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
namespace
{
constexpr uint16_t kDefaultPort = 9000;
constexpr size_t kUdpBufferSize = 512;
constexpr uint16_t kRequiredFields = (1u << 9) - 1u;

enum class Field : uint8_t {
	TrackStatus = 0,
	PitchAngle,
	YawAngle,
	PitchMisalignment,
	YawMisalignment,
	TrackingConfidence,
	TargetConfidence,
	PitchLosRate,
	YawLosRate,
	GyroPitchRate,
	GyroYawRate,
};

struct AishengFields {
	uint8_t track_status{0};
	float pitch_angle{0.f};
	float yaw_angle{0.f};
	float pitch_misalignment{0.f};
	float yaw_misalignment{0.f};
	float tracking_confidence{0.f};
	float target_confidence{0.f};
	float pitch_los_rate{0.f};
	float yaw_los_rate{0.f};
	float gyro_pitch_rate{0.f};
	float gyro_yaw_rate{0.f};
};

class JsonParser
{
public:
	JsonParser(const char *data, size_t length) : _cursor(data), _end(data + length) {}

	bool parse(AishengFields &fields)
	{
		skip_whitespace();

		if (!consume('{')) { return false; }

		skip_whitespace();

		if (consume('}')) { return false; }

		uint16_t seen = 0;

		while (_cursor < _end) {
			char key[32] {};

			if (!parse_string(key, sizeof(key))) { return false; }

			skip_whitespace();

			if (!consume(':')) { return false; }

			skip_whitespace();
			const int field = field_index(key);

			if (field >= 0) {
				const uint16_t bit = static_cast<uint16_t>(1u << field);

				if ((seen & bit) != 0) { return false; }

				float value = 0.f;

				if (!parse_number(value) || !assign_field(static_cast<Field>(field), value, fields)) {
					return false;
				}

				seen |= bit;

			} else if (!skip_value(0)) {
				return false;
			}

			skip_whitespace();

			if (consume('}')) { break; }

			if (!consume(',')) { return false; }

			skip_whitespace();
		}

		skip_whitespace();
		// 陀螺仪字段可选；保持既有九字段报文兼容。
		return _cursor == _end && (seen & kRequiredFields) == kRequiredFields;
	}

private:
	static bool is_whitespace(char value)
	{
		return value == ' ' || value == '\t' || value == '\r' || value == '\n';
	}

	static bool is_digit(char value) { return value >= '0' && value <= '9'; }

	void skip_whitespace()
	{
		while (_cursor < _end && is_whitespace(*_cursor)) { ++_cursor; }
	}

	bool consume(char expected)
	{
		if (_cursor >= _end || *_cursor != expected) { return false; }

		++_cursor;
		return true;
	}

	bool consume_literal(const char *literal)
	{
		const size_t length = strlen(literal);

		if (static_cast<size_t>(_end - _cursor) < length || strncmp(_cursor, literal, length) != 0) {
			return false;
		}

		_cursor += length;
		return true;
	}

	bool parse_string(char *output, size_t output_size)
	{
		if (!consume('"')) { return false; }

		size_t written = 0;
		bool overflow = false;

		while (_cursor < _end) {
			char value = *_cursor++;

			if (value == '"') {
				if (output != nullptr && output_size > 0) {
					if (overflow) {
						output[0] = '\0';

					} else {
						output[written] = '\0';
					}
				}

				return true;
			}

			if (static_cast<unsigned char>(value) < 0x20) { return false; }

			if (value == '\\') {
				if (_cursor >= _end) { return false; }

				const char escaped = *_cursor++;

				switch (escaped) {
				case '"': value = '"'; break;
				case '\\': value = '\\'; break;
				case '/': value = '/'; break;
				case 'b': value = '\b'; break;
				case 'f': value = '\f'; break;
				case 'n': value = '\n'; break;
				case 'r': value = '\r'; break;
				case 't': value = '\t'; break;

				case 'u':
					for (unsigned i = 0; i < 4; ++i) {
						if (_cursor >= _end
						    || !(is_digit(*_cursor) || (*_cursor >= 'a' && *_cursor <= 'f')
							 || (*_cursor >= 'A' && *_cursor <= 'F'))) {
							return false;
						}

						++_cursor;
					}

					value = '?';
					break;

				default: return false;
				}
			}

			if (output != nullptr && output_size > 0) {
				if (written + 1 < output_size) {
					output[written++] = value;

				} else {
					overflow = true;
				}
			}
		}

		return false;
	}

	bool parse_number(float &value)
	{
		const char *start = _cursor;

		if (_cursor < _end && *_cursor == '-') { ++_cursor; }

		if (_cursor >= _end) { return false; }

		if (*_cursor == '0') {
			++_cursor;

			if (_cursor < _end && is_digit(*_cursor)) { return false; }

		} else if (*_cursor >= '1' && *_cursor <= '9') {
			while (_cursor < _end && is_digit(*_cursor)) { ++_cursor; }

		} else {
			return false;
		}

		if (_cursor < _end && *_cursor == '.') {
			++_cursor;

			if (_cursor >= _end || !is_digit(*_cursor)) { return false; }

			while (_cursor < _end && is_digit(*_cursor)) { ++_cursor; }
		}

		if (_cursor < _end && (*_cursor == 'e' || *_cursor == 'E')) {
			++_cursor;

			if (_cursor < _end && (*_cursor == '+' || *_cursor == '-')) { ++_cursor; }

			if (_cursor >= _end || !is_digit(*_cursor)) { return false; }

			while (_cursor < _end && is_digit(*_cursor)) { ++_cursor; }
		}

		char *conversion_end = nullptr;
		value = strtof(start, &conversion_end);
		return conversion_end == _cursor && std::isfinite(value);
	}

	bool skip_value(unsigned depth)
	{
		if (depth > 8 || _cursor >= _end) { return false; }

		if (*_cursor == '"') { return parse_string(nullptr, 0); }

		if (*_cursor == '{') {
			++_cursor;
			skip_whitespace();

			if (consume('}')) { return true; }

			while (_cursor < _end) {
				if (!parse_string(nullptr, 0)) { return false; }

				skip_whitespace();

				if (!consume(':')) { return false; }

				skip_whitespace();

				if (!skip_value(depth + 1)) { return false; }

				skip_whitespace();

				if (consume('}')) { return true; }

				if (!consume(',')) { return false; }

				skip_whitespace();
			}

			return false;
		}

		if (*_cursor == '[') {
			++_cursor;
			skip_whitespace();

			if (consume(']')) { return true; }

			while (_cursor < _end) {
				if (!skip_value(depth + 1)) { return false; }

				skip_whitespace();

				if (consume(']')) { return true; }

				if (!consume(',')) { return false; }

				skip_whitespace();
			}

			return false;
		}

		if (consume_literal("true") || consume_literal("false") || consume_literal("null")) { return true; }

		float unused = 0.f;
		return parse_number(unused);
	}

	static int field_index(const char *key)
	{
		if (strcmp(key, "track_status") == 0) { return static_cast<int>(Field::TrackStatus); }

		if (strcmp(key, "pitch_angle") == 0) { return static_cast<int>(Field::PitchAngle); }

		if (strcmp(key, "yaw_angle") == 0) { return static_cast<int>(Field::YawAngle); }

		if (strcmp(key, "pitch_misalignment") == 0) { return static_cast<int>(Field::PitchMisalignment); }

		if (strcmp(key, "yaw_misalignment") == 0) { return static_cast<int>(Field::YawMisalignment); }

		if (strcmp(key, "tracking_confidence") == 0) { return static_cast<int>(Field::TrackingConfidence); }

		if (strcmp(key, "target_confidence") == 0) { return static_cast<int>(Field::TargetConfidence); }

		if (strcmp(key, "pitch_los_rate") == 0) { return static_cast<int>(Field::PitchLosRate); }

		if (strcmp(key, "yaw_los_rate") == 0) { return static_cast<int>(Field::YawLosRate); }

		if (strcmp(key, "gyro_pitch_rate") == 0) { return static_cast<int>(Field::GyroPitchRate); }

		if (strcmp(key, "gyro_yaw_rate") == 0) { return static_cast<int>(Field::GyroYawRate); }

		return -1;
	}

	static bool assign_field(Field field, float value, AishengFields &fields)
	{
		switch (field) {
		case Field::TrackStatus:
			if (fabsf(value) < 0.000001f) {
				fields.track_status = 0;

			} else if (fabsf(value - 1.f) < 0.000001f) {
				fields.track_status = 1;

			} else {
				return false;
			}

			break;

		case Field::PitchAngle: fields.pitch_angle = value; break;
		case Field::YawAngle: fields.yaw_angle = value; break;
		case Field::PitchMisalignment: fields.pitch_misalignment = value; break;
		case Field::YawMisalignment: fields.yaw_misalignment = value; break;
		case Field::TrackingConfidence: fields.tracking_confidence = value; break;
		case Field::TargetConfidence: fields.target_confidence = value; break;
		case Field::PitchLosRate: fields.pitch_los_rate = value; break;
		case Field::YawLosRate: fields.yaw_los_rate = value; break;
		case Field::GyroPitchRate: fields.gyro_pitch_rate = value; break;
		case Field::GyroYawRate: fields.gyro_yaw_rate = value; break;
		}

		return true;
	}

	const char *_cursor;
	const char *_end;
};
}

static void check(bool condition, const char *message) {
 if (!condition) throw std::runtime_error(message);
}
static bool parse(const std::string &data, AishengFields &out) {
 return JsonParser(data.data(), data.size()).parse(out);
}
int main() {
 const std::string base=R"({"track_status":1,"pitch_angle":-12.5,"yaw_angle":23.75,"pitch_misalignment":-1.25,"yaw_misalignment":2.5,"tracking_confidence":25.5,"target_confidence":0.8,"pitch_los_rate":19,"yaw_los_rate":-17})";
 auto packet=[&](const std::string &extra) {return base.substr(0,base.size()-1)+","+extra+"}";};
 unsigned passed=0;
 auto run=[&](const std::string &name,const std::function<void()> &test) {
  try {test();++passed;std::cout<<"PASS "<<name<<"\n";}
  catch(const std::exception &error) {std::cerr<<"FAIL "<<name<<": "<<error.what()<<"\n";std::exit(1);}
 };
 run("legacy_nine_fields_zero_gyro",[&] {
  AishengFields f{};check(parse(base,f),"旧九字段包应接受");
  check(f.gyro_pitch_rate==0 && f.gyro_yaw_rate==0,"旧包gyro默认0");
  check(f.pitch_los_rate==19 && f.yaw_los_rate==-17,"旧LOS保真");
 });
 run("new_13_fields_distinct_gyro_and_los",[&] {
  AishengFields f{};check(parse(packet(R"("gyro_pitch_rate":7.25,"gyro_yaw_rate":-8.5,"tracking_gateW":100,"tracking_gateH":80)"),f),"新十三字段包应接受");
  check(f.gyro_pitch_rate==7.25f && f.gyro_yaw_rate==-8.5f,"gyro不应丢弃或反号");
  check(f.pitch_los_rate==19 && f.yaw_los_rate==-17,"gyro不能覆盖LOS");
  check(f.pitch_angle==-12.5f && f.yaw_angle==23.75f && f.track_status==1,"其余字段不变");
 });
 run("pitch_optional_without_yaw",[&] {
  AishengFields f{};check(parse(packet(R"("gyro_pitch_rate":-3.5)"),f),"单独pitch可接受");
  check(f.gyro_pitch_rate==-3.5f && f.gyro_yaw_rate==0,"另一个缺省0");
 });
 run("yaw_optional_without_pitch",[&] {
  AishengFields f{};check(parse(packet(R"("gyro_yaw_rate":4.5)"),f),"单独yaw可接受");
  check(f.gyro_pitch_rate==0 && f.gyro_yaw_rate==4.5f,"另一个缺省0");
 });
 for (const std::string field:{"gyro_pitch_rate","gyro_yaw_rate"}) {
  run(field+"_duplicate_rejected",[&] {
   AishengFields f{};check(!parse(packet("\""+field+"\":1,\""+field+"\":2"),f),"重复已知gyro必须拒绝");
  });
  for (const std::string value:{"null","true","\"3\"","[]","NaN","Infinity","1e99"}) {
   run(field+"_invalid_"+value,[&] {
    AishengFields f{};check(!parse(packet("\""+field+"\":"+value),f),"非法gyro必须拒绝");
   });
  }
 }
 run("zero_los_preserves_nonzero_gyro",[&] {
  auto p=packet(R"("gyro_pitch_rate":-20,"gyro_yaw_rate":20)");
  auto replace=[&](const std::string &a,const std::string &b){p.replace(p.find(a),a.size(),b);};
  replace("\"pitch_los_rate\":19","\"pitch_los_rate\":0");
  replace("\"yaw_los_rate\":-17","\"yaw_los_rate\":0");
  AishengFields f{};check(parse(p,f),"LOS无效报文的0值可接受");
  check(f.pitch_los_rate==0 && f.yaw_los_rate==0 && f.gyro_pitch_rate==-20 && f.gyro_yaw_rate==20,"机械与LOS必须独立");
 });
 run("required_field_still_required",[&] {
  std::string p=base;p.erase(p.find("\"yaw_los_rate\""));p.pop_back();p+="}";
  AishengFields f{};check(!parse(p,f),"旧required字段仍然必需");
 });
 run("unknown_extra_still_compatible",[&] {
  AishengFields f{};check(parse(packet(R"("other":{"optional":[1,true,null]})"),f),"未知扩展字段仍允许");
 });
 std::cout<<"TOTAL "<<passed<<"\n";
}
