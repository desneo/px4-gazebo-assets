#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""云台侧网络网关（gz-transport -> IP:端口）。

把 Gazebo 内 `gz-two-axis-pod-controller` 插件暴露的 gz-transport 话题，桥接成地面站可用的
UDP + RTSP 接口，对外控制和遥测协议见
`models/gimbals/two_axis_pod/docs/control-protocol.md`。视频为 RTSP/RTP over UDP。

gz-transport 侧（与插件对接）：
- 订阅 ``/two_axis_pod/telemetry``（StringMsg，JSON 遥测）
- 订阅 ``/two_axis_pod/command_result``（StringMsg，JSON 指令结果）
- 发布 ``/two_axis_pod/command``（StringMsg，JSON 指令）-> 插件
- 复用 ``gz_source.py`` 的 ``GzSource``：相机图像 + 仿真时钟 -> 单调时钟映射

网络侧（面向地面站，见 models/gimbals/two_axis_pod/docs/control-protocol.md）：
- UDP ``udp://<host>:8766``：一条数据报 = 一条 UTF-8 JSON；服务端按客户端地址登记并
  按插件产生的新样本逐份广播 ``telemetry``；指令经 ``seq`` 幂等去重后转插件。
- RTSP ``rtsp://<host>:8555/two_axis_pod_<aircraft_id>``：H.264（复用 ``video.py``）

线程模型：``video_thread`` 只取最新帧投递；
``telemetry_thread`` 负责 UDP 遥测广播；主线程阻塞在 UDP 接收循环；gz-transport
回调线程只更新共享状态（``command_result`` 按唯一请求 ID 关联 ``seq`` 后转发）。
"""
from __future__ import annotations

import argparse
import json
import math
import os
import signal
import socket
import sys
import threading
import time
import uuid
from pathlib import Path
from collections import deque

import numpy as np

from gz.msgs10.image_pb2 import Image  # noqa: E402
from gz.msgs10.stringmsg_pb2 import StringMsg  # noqa: E402

from gz_source import GzSource  # noqa: E402
from telemetry_config import DEFAULT_TELEMETRY_CONFIG, load_telemetry_config
from rtsp_relay import aircraft_mount
from video import VideoStreamer  # noqa: E402
from vision import (DetectorConfig, TrackerConfig, VisionEngine,
                    draw_tracks_rgb, nearest_confirmed_track)  # noqa: E402

STAMP_MASK = 0xFFFFFF

TELEMETRY_TOPIC = "/two_axis_pod/telemetry"
COMMAND_TOPIC = "/two_axis_pod/command"
RESULT_TOPIC = "/two_axis_pod/command_result"

# 单条数据报上限（docs/control-protocol.md：8 KiB），超过不发送/丢弃
MAX_DATAGRAM = 8 * 1024
# UDP 接收缓冲区，足以接收任意合法数据报。
RECV_BUFFER = 65535
SEQ_WINDOW = 1024
MAX_PENDING = 4096
RESULT_TIMEOUT = 30.0
SESSION_RETENTION = 60.0

# 直接透传给插件的指令（插件负责执行并回 command_result）
PASSTHROUGH_CMDS = {"track", "stop", "home", "reset", "reset_axis", "manual", "reset_fault"}
LOCAL_CMDS = {"set_vision_mode"}
VISION_MODES = {"off", "detect", "auto_lock", "manual_track"}
DEFAULT_VISION_CONFIG = Path(__file__).with_name("vision.json")


def load_vision_config(path: Path) -> dict:
    """读取视觉配置，并把相对模型路径按配置文件所在目录解析。"""
    path = Path(path).expanduser().resolve()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ValueError(f"无法读取视觉配置 {path}: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"视觉配置不是有效 JSON {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("视觉配置根节点必须是对象")
    model_path = data.get("model_path")
    if not isinstance(model_path, str) or not model_path.strip():
        raise ValueError("视觉配置 model_path 必须是非空字符串")
    resolved = Path(model_path).expanduser()
    if not resolved.is_absolute():
        resolved = path.parent / resolved
    data["model_path"] = resolved.resolve()
    data["config_path"] = path
    return data

def _as_int(value):
    """把候选 seq 规整为 int；布尔/非整数/缺失返回 None。"""
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return None


class _Client:
    """一个已登记客户端地址的会话状态，见 docs/control-protocol.md。"""

    __slots__ = ("addr", "last_seen", "highest_seq", "last_control_seq", "seen", "results")

    def __init__(self, addr):
        self.addr = addr
        self.last_seen = time.monotonic()
        self.highest_seq = -1
        self.last_control_seq = -1
        self.seen: dict[int, str] = {}          # seq -> 请求内容
        self.results: dict[int, list[str]] = {}  # seq -> 已生成的回执载荷


class GimbalBridge:
    """gz-transport <-> UDP/RTSP 网关。"""

    def __init__(self, args):
        self.args = args
        self._running = True
        self._t_start = time.time()

        # GzSource：提供 gz-transport Node、相机帧与仿真->单调时钟映射
        self.source = GzSource(args.world, args.gimbal_model)

        self.lock = threading.RLock()
        self._vision_lock = threading.RLock()
        self._telemetry_ready = threading.Condition(self.lock)
        self._telemetry_pending = deque(maxlen=1000)
        self._last_queued_stamp = None
        self._last_telemetry_warning = -math.inf
        self._latest_tel = None                 # 插件遥测 JSON -> dict
        self._latest_tel_received = None        # 插件遥测的接收单调时钟时间
        self._plugin_protocol_compatible = False
        self._frame = None                      # (seq,w,h,sim_stamp,t_arrive,t0,data)
        self._img_counter = 0
        self.frame_registry = deque(maxlen=600)  # (seq24, t0_mono)
        self._last_reg_seq = None
        self._vision = None
        self._vision_config = load_vision_config(args.vision_config)
        self._vision_frame_size = None
        self._vision_failed = False
        self._vision_mode = "off"
        self._vision_state = "OFF"
        self._vision_error = None
        self._locked_track_id = None
        self._vision_target_count = 0
        self._vision_metrics = {}
        self._camera_times = deque(maxlen=120)
        self._vision_times = deque(maxlen=120)
        self._last_vision_seq = None
        self._auto_lock_sent_at = None
        self._last_tracking_stop_at = -math.inf

        self.clients_lock = threading.RLock()
        self.clients: dict[tuple, _Client] = {}
        self.retired_clients: dict[tuple, _Client] = {}
        self.pending_requests: dict[str, tuple] = {}
        try:
            self.clock_domain = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
        except OSError:
            self.clock_domain = None

        self.video: VideoStreamer | None = None
        self._video_error: str | None = None

        # UDP 控制/遥测服务端（docs/control-protocol.md）
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF,
                                 max(1 << 20, RECV_BUFFER))
        except OSError:
            pass
        self.sock.bind((args.udp_host, args.udp_port))
        self.sock.settimeout(0.5)               # 便于 _running 翻转后及时退出

        # gz-transport：订阅插件遥测/结果，发布指令
        prefix = getattr(args, "topic_prefix", "/two_axis_pod").rstrip("/")
        self._cmd_pub = self.source.node.advertise(f"{prefix}/command", StringMsg)
        self.source.node.subscribe(StringMsg, f"{prefix}/telemetry", self._on_telemetry)
        self.source.node.subscribe(StringMsg, f"{prefix}/command_result", self._on_command_result)
        # 相机图像：话题名可配（GzSource 内部固定订阅默认 link/sensor，
        # 这里按参数重新订阅，保证 --camera-link/--camera-sensor 生效）
        img_topic = getattr(args, "image_topic", None) or (
            f"/world/{args.world}/model/{args.gimbal_model}/link/"
            f"{args.camera_link}/sensor/{args.camera_sensor}/image")
        self.source.node.subscribe(Image, img_topic, self._on_image)
        print(f"[bridge] 订阅图像 {img_topic}")

    # ---------------- gz-transport 回调（非主线程） ----------------
    def _on_telemetry(self, msg):
        try:
            tel = json.loads(msg.data)
        except (json.JSONDecodeError, TypeError):
            return
        if not isinstance(tel, dict):
            return
        compatible = (type(tel.get("protocol_version")) is int
                      and tel["protocol_version"] == 8
                      and tel.get("angle_convention") == "motion_head_joint_right_positive")
        with self.lock:
            changed = compatible != self._plugin_protocol_compatible
            self._plugin_protocol_compatible = compatible
            if not compatible:
                self._latest_tel = None
                self._latest_tel_received = None
                self._telemetry_pending.clear()
        if changed:
            # 不持有遥测锁取得客户端锁，避免与命令处理形成锁顺序反转。
            with self.clients_lock:
                for addr in list(self.clients):
                    self._send_hello(addr)
        if not compatible:
            return
        with self.lock:
            self._latest_tel = tel
            self._latest_tel_received = time.monotonic()
            # 网关重启不能让默认 off 与插件遗留 TRACK 并存；停止发布可能
            # 早于 Transport 建连，按遥测限频重试，直到实际退出跟踪。
            # off/detect 仍允许人工转动和回零，只清理残留的 TRACK。
            now = self._latest_tel_received
            if (self._vision_mode in {"off", "detect"} and tel.get("mode") == "TRACK"
                    and now - getattr(self, "_last_tracking_stop_at", -math.inf) >= .25):
                self._last_tracking_stop_at = now
                self._publish_internal("stop")

            # 发送节拍由新姿态驱动；旧插件或不同配置不得靠重发补齐频率。
            hz = tel.get("telemetry_hz")
            telemetry_clock = tel.get("telemetry_clock")
            stamp = tel.get("ts_mono")
            if (isinstance(hz, bool) or not isinstance(hz, (int, float))
                    or not 0 < hz <= 1000 or not math.isfinite(hz)
                    or not math.isclose(hz, self.args.telemetry_hz, rel_tol=1e-9)
                    or telemetry_clock != "steady"):
                if now - getattr(self, "_last_telemetry_warning", -math.inf) >= 1.0:
                    self._last_telemetry_warning = now
                    print(f"[udp] 插件频率 {hz!r}、时钟 {telemetry_clock!r} 与配置 "
                          f"{self.args.telemetry_hz} Hz/steady 不一致；"
                          "暂停周期遥测，请核对配置并重启插件和网关", flush=True)
                return
            try:
                valid_stamp = (not isinstance(stamp, bool)
                               and isinstance(stamp, (int, float))
                               and math.isfinite(stamp))
            except OverflowError:
                valid_stamp = False
            if not valid_stamp or stamp == self._last_queued_stamp:
                return
            self._last_queued_stamp = stamp
            if len(self._telemetry_pending) == self._telemetry_pending.maxlen:
                if now - self._last_telemetry_warning >= 1.0:
                    self._last_telemetry_warning = now
                    print("[udp] 遥测发送积压，丢弃最旧样本", flush=True)
            self._telemetry_pending.append(self.snapshot())
            self._telemetry_ready.notify()

    def _on_command_result(self, msg):
        try:
            data = json.loads(msg.data)
        except (json.JSONDecodeError, TypeError):
            return
        if not isinstance(data, dict):
            return
        data.setdefault("type", "command_result")
        self._forward_command_result(data)

    def _on_image(self, msg):
        t_arrive = time.monotonic()
        seq = None
        for entry in msg.header.data:
            if entry.key == "seq" and len(entry.value) > 0:
                try:
                    seq = int(entry.value[0])
                except ValueError:
                    pass
        if seq is None:
            with self.lock:
                self._img_counter += 1
                seq = self._img_counter
        sim_stamp = msg.header.stamp.sec + msg.header.stamp.nsec * 1e-9
        off = self.source.clock_offset
        t0 = (sim_stamp + off) if off > 0 else t_arrive
        with self.lock:
            self._frame = (seq, int(msg.width), int(msg.height), sim_stamp,
                           t_arrive, t0, bytes(msg.data))
            self._camera_times.append(t_arrive)

    # ---------------- 视频线程 ----------------
    def video_thread(self):
        last_frame_seq = None
        while self._running:
            with self.lock:
                frame = self._frame
            if frame is None or frame[0] == last_frame_seq:
                time.sleep(.001)
                continue
            seq, w, h, _sim, _arr, t0, data = frame
            last_frame_seq = seq
            if self.video is None and self._video_error is None:
                self._start_video(w, h)
            if self.video is not None:
                data = self._process_vision_frame(seq, w, h, data)
                seq24 = seq & STAMP_MASK
                if self.video.push(seq24, data, t0):
                    with self.lock:
                        if seq24 != self._last_reg_seq:
                            self.frame_registry.append((seq24, t0))
                            self._last_reg_seq = seq24

    @staticmethod
    def _rate(samples) -> float:
        if len(samples) < 2:
            return 0.0
        elapsed = samples[-1] - samples[0]
        return (len(samples) - 1) / elapsed if elapsed > 0.0 else 0.0

    def _build_vision(self, width, height):
        cfg = self._vision_config
        detector = DetectorConfig(
            model_path=cfg["model_path"], input_size=int(cfg.get("input_size", 640)),
            frame_width=width, frame_height=height,
            confidence_threshold=float(cfg.get("confidence_threshold", 0.5)),
            low_confidence_threshold=float(cfg.get("low_confidence_threshold", 0.1)),
            nms_iou_threshold=float(cfg.get("nms_iou_threshold", 0.45)),
            opencv_threads=int(cfg.get("opencv_threads", 2)))
        tracker = TrackerConfig(
            confirmation_hits=int(cfg.get("confirmation_hits", 5)),
            max_missed=int(cfg.get("max_missed", 15)),
            high_confidence_threshold=detector.confidence_threshold,
            low_confidence_threshold=detector.low_confidence_threshold,
            high_match_iou=float(cfg.get("high_match_iou", 0.3)),
            low_match_iou=float(cfg.get("low_match_iou", 0.2)))
        self._vision = VisionEngine(detector, tracker)
        self._vision_frame_size = (width, height)
        self._vision_failed = False
        print(f"[vision] 单类 aircraft 模型已加载: {detector.model_path}，"
              f"连续命中 {tracker.confirmation_hits} 帧确认", flush=True)

    def _process_vision_frame(self, seq, width, height, data):
        """处理最新相机帧；同步推理使检测框与编码帧保持一一对应。"""
        with self.lock:
            mode = self._vision_mode
            last_seq = self._last_vision_seq
        if mode not in {"detect", "auto_lock"} or seq == last_seq:
            return data
        # 自动锁定只把检测器用于搜索和选框。一旦框交给插件单目标后端，视频恢复
        # 原始画面，由地面站根据插件遥测绘制单个绿色框；不再叠加多目标红框。
        if mode == "auto_lock" and self._auto_tracker_controls_frame():
            return data
        if len(data) != width * height * 3:
            with self.lock:
                self._vision_error = (f"RGB 帧长度错误：期望 {width * height * 3}，"
                                      f"实际 {len(data)}")
                self._vision_state = "ERROR"
            return data
        try:
            with self._vision_lock:
                if self._vision is None or self._vision_frame_size != (width, height):
                    if self._vision_failed:
                        return data
                    self._build_vision(width, height)
                rgb = np.frombuffer(data, dtype=np.uint8).reshape(height, width, 3)
                result = self._vision.process_rgb(rgb, seq)
                annotated = draw_tracks_rgb(rgb, result.tracks)
            now = time.monotonic()
            with self.lock:
                self._last_vision_seq = seq
                self._vision_times.append(now)
                self._vision_target_count = len(result.tracks)
                self._vision_error = None
                self._vision_metrics = {
                    "inference_ms": round(result.inference_ms, 3),
                    "input_fps": round(self._rate(self._camera_times), 2),
                    "output_fps": round(self._rate(self._vision_times), 2),
                }
            if mode == "auto_lock":
                self._update_auto_lock(result, width, height)
            else:
                with self.lock:
                    self._vision_state = "DETECTING"
            return annotated.tobytes()
        except Exception as exc:  # noqa: BLE001 - 原始视频仍应可诊断
            with self.lock:
                self._vision_failed = True
                self._vision_error = str(exc)
                self._vision_state = "ERROR"
                self._vision_target_count = 0
            print(f"[vision] 目标检测停止：{exc}", flush=True)
            if mode == "auto_lock":
                self._publish_internal("stop")
            return data

    def _auto_tracker_controls_frame(self):
        """锁定后由插件配置的后端独占单目标跟踪；最终丢失才恢复检测搜索。"""
        with self.lock:
            tel = self._latest_tel or {}
            tracking_state = ((tel.get("tracking") or {}).get("state"))
            locked_id = self._locked_track_id
            sent_at = self._auto_lock_sent_at
        if locked_id is None:
            return False
        release = tracking_state in {"LOST", "FAULT"}
        if (tracking_state in {"IDLE", "INIT"} and sent_at is not None
                and time.monotonic() - sent_at > .75):
            # 插件未接受精确帧或初始化未完成；释放目标后从最新检测重新选择。
            release = True
        if release:
            self._publish_internal("stop")
            with self.lock:
                self._locked_track_id = None
                self._auto_lock_sent_at = None
                self._vision_target_count = 0
                self._vision_state = "AUTO_SEARCH"
                vision = self._vision
            if vision is not None and hasattr(vision, "reset"):
                with self._vision_lock:
                    vision.reset()
            return False
        with self.lock:
            self._vision_target_count = 1
            self._vision_state = ("AUTO_LOCKED" if tracking_state == "TRACK"
                                  else "AUTO_ACQUIRING")
        return True

    def _update_auto_lock(self, result, width, height):
        """搜索阶段选中中心最近目标，并把检测框交给插件单目标后端。"""
        target = nearest_confirmed_track(result.tracks, width, height)
        if target is None:
            with self.lock:
                self._vision_state = "AUTO_SEARCH"
            return
        x1, y1, x2, y2 = target.xyxy
        box = [max(0.0, min(1.0, x1 / width)),
               max(0.0, min(1.0, y1 / height)),
               max(1.0 / width, min(1.0, (x2 - x1) / width)),
               max(1.0 / height, min(1.0, (y2 - y1) / height))]
        if box[0] + box[2] > 1.0:
            box[2] = 1.0 - box[0]
        if box[1] + box[3] > 1.0:
            box[3] = 1.0 - box[1]
        if self._publish_internal("track", box=box, frame_seq=result.seq):
            with self.lock:
                self._locked_track_id = target.track_id
                self._auto_lock_sent_at = time.monotonic()
                self._vision_target_count = 1
                self._vision_state = "AUTO_ACQUIRING"
        else:
            with self.lock:
                self._vision_error = "自动锁定指令发布失败"
                self._vision_state = "ERROR"

    def _start_video(self, width, height):
        try:
            self.video = VideoStreamer(width, height,
                                       rtsp_port=self.args.rtsp_port,
                                       mount=self.args.mount,
                                       bitrate_kbps=self.args.video_bitrate,
                                       udp_port=self.args.rtp_port,
                                       on_error=self._on_video_error)
            print(f"[video] RTSP 服务已启动 "
                  f"rtsp://0.0.0.0:{self.args.rtsp_port}{self.args.mount} "
                  f"({width}x{height}, encoder=NVENC)",
                  flush=True)
        except Exception as exc:  # noqa: BLE001 - 硬编码是运行前提，失败即终止
            self._video_error = str(exc)
            print(f"[video] NVIDIA NVENC 硬编码不可用，网关终止: {exc}",
                  flush=True)
            self._running = False
            try:
                self.sock.close()
            except OSError:
                pass

    def _on_video_error(self, message):
        """硬编码运行期失败时终止网关，禁止无视频继续控制。"""
        self._video_error = str(message)
        print(f"[video] NVIDIA NVENC 运行失败，网关终止: {message}", flush=True)
        self._running = False
        with self._telemetry_ready:
            self._telemetry_ready.notify_all()
        try:
            self.sock.close()
        except OSError:
            pass

    def _publish_internal(self, cmd, **extra):
        """发布网关内部控制命令；回执仅用于插件诊断，不属于任一客户端。"""
        if cmd == "track" and not self._plugin_protocol_compatible:
            return False
        message = StringMsg()
        message.data = json.dumps({"cmd": cmd,
                                   "request_id": "bridge-" + uuid.uuid4().hex,
                                   **extra})
        try:
            return self._cmd_pub.publish(message) is not False
        except Exception:
            return False

    def _set_vision_mode(self, mode, *, force_stop=False):
        """原子切换互斥视觉模式，并停止前一模式留下的跟踪输出。"""
        if mode not in VISION_MODES:
            raise ValueError(f"无效视觉模式 {mode}")
        with self.lock:
            previous = self._vision_mode
            self._vision_mode = mode
            self._locked_track_id = None
            self._vision_target_count = 0
            self._vision_error = None
            self._vision_failed = False
            self._vision_metrics = {}
            self._vision_times.clear()
            self._vision_state = {
                "off": "OFF",
                "detect": "DETECTING",
                "auto_lock": "AUTO_SEARCH",
                "manual_track": "MANUAL_READY",
            }[mode]
            vision = self._vision
            self._last_vision_seq = None
            self._auto_lock_sent_at = None
        if vision is not None and hasattr(vision, "reset"):
            with self._vision_lock:
                vision.reset()
        with self.lock:
            if self._vision_mode == mode:
                self._vision_state = {
                    "off": "OFF",
                    "detect": "DETECTING",
                    "auto_lock": "AUTO_SEARCH",
                    "manual_track": "MANUAL_READY",
                }[mode]
        if previous != mode or force_stop:
            self._publish_internal("stop")

    # ---------------- 遥测组装 ----------------
    def snapshot(self) -> dict | None:
        with self.lock:
            tel = self._latest_tel
            table = list(self.frame_registry)[-60:]
            vision = {
                "mode": self._vision_mode,
                "state": self._vision_state,
                "target_count": self._vision_target_count,
                "locked_track_id": self._locked_track_id,
                "error": self._vision_error,
                **self._vision_metrics,
            }
        if tel is None or not self._plugin_protocol_compatible:
            return None
        out = dict(tel)  # 插件遥测所有字段
        out.setdefault("type", "telemetry")
        out["aircraft_id"] = getattr(self.args, "aircraft_id", 1)
        out["video_rtsp_path"] = self.args.mount
        out["frame_table"] = [[int(s), round(t0, 6)] for (s, t0) in table]
        out["video"] = {
            "pushed": self.video.frames_pushed if self.video else 0,
            "dropped": self.video.frames_dropped if self.video else 0,
            "clients": self.video.clients if self.video else 0,
        }
        out["vision"] = vision
        # 便于地面站做时钟/存活判断（docs/control-protocol.md；插件未提供）
        out["ts_wall"] = round(time.time(), 6)
        out["server_uptime"] = round(time.time() - self._t_start, 1)
        return out

    # ---------------- UDP 发送 ----------------
    def _send_json(self, addr, payload: dict | str) -> bool:
        text = payload if isinstance(payload, str) else json.dumps(payload)
        data = text.encode("utf-8")
        if len(data) > MAX_DATAGRAM:
            print(f"[udp] 丢弃超长数据报 {len(data)}B -> {addr}", flush=True)
            return False
        try:
            self.sock.sendto(data, addr)
            return True
        except OSError as exc:  # noqa: BLE001
            print(f"[udp] 发送到 {addr} 失败: {exc}", flush=True)
            return False

    # ---------------- 客户端登记 ----------------
    def _send_hello(self, addr):
        compatible = self._plugin_protocol_compatible
        self._send_json(addr, {
            "type": "hello",
            "proto": "gimbal-udp",
            "version": 8 if compatible else None,
            "angle_convention": "motion_head_joint_right_positive" if compatible else None,
            "plugin_compatible": compatible,
            "clock_domain": self.clock_domain,
            "telemetry_hz": self.args.telemetry_hz,
            "telemetry_clock": "steady",
            "video_rtsp_path": self.args.mount,
            "aircraft_id": getattr(self.args, "aircraft_id", 1),
            "capabilities": ["vision_mode", "server_video_overlay", "auto_lock", "frame_exact_track"],
        })

    def _on_datagram(self, data: bytes, addr):
        if len(data) > MAX_DATAGRAM:
            print(f"[udp] 丢弃超长数据报 {len(data)}B <- {addr}", flush=True)
            return
        try:
            text = data.decode("utf-8").strip()
        except UnicodeDecodeError:
            self._send_json(addr, {"type": "error", "message": "非 UTF-8 数据报",
                                   "seq": None})
            return
        if not text:
            return
        try:
            msg = json.loads(text)
        except json.JSONDecodeError:
            self._send_json(addr, {"type": "error", "message": "无效 JSON",
                                   "seq": None})
            return
        if not isinstance(msg, dict):
            self._send_json(addr, {"type": "error", "message": "无效 JSON",
                                   "seq": None})
            return
        cmd = msg.get("cmd")
        if not isinstance(cmd, str) or cmd not in PASSTHROUGH_CMDS | LOCAL_CMDS | {"ping", "bye", "status"}:
            self._send_json(addr, {"type": "command_result", "cmd": cmd if isinstance(cmd, str) else None,
                                   "seq": _as_int(msg.get("seq")), "ok": False,
                                   "message": "无效指令"})
            return
        now = time.monotonic()
        with self.clients_lock:
            self._expire_requests(now)
            cl = self.clients.get(addr)
            if cl is not None and now - cl.last_seen > self.args.client_timeout:
                self._retire_client(cl)
                cl = None
            new = cl is None
            if new:
                cl = self.retired_clients.pop(addr, None) or _Client(addr)
                self.clients[addr] = cl
            cl.last_seen = now
        if new:
            if cmd != "ping":
                self._send_hello(addr)
            print(f"[udp] 客户端登记 {addr}，当前 {len(self.clients)} 个", flush=True)
        self._handle_command(cl, msg)

    # ---------------- 指令处理（docs/control-protocol.md） ----------------
    def _handle_command(self, cl: _Client, msg: dict):
        # 与插件回调、会话过期共用锁，先登记关联再发布。
        with self.clients_lock:
            self._handle_command_locked(cl, msg)

    def _handle_command_locked(self, cl: _Client, msg: dict):
        addr = cl.addr
        cmd = msg.get("cmd")
        seq = _as_int(msg.get("seq"))
        if "seq" in msg and (seq is None or seq < 0):
            self._send_json(addr, {"type": "command_result", "cmd": cmd,
                                   "seq": msg.get("seq"), "ok": False,
                                   "message": "seq 必须是非负整数"})
            return
        if not isinstance(cmd, str):
            self._reply_and_cache(cl, seq, {"type": "command_result", "cmd": None,
                                            "ok": False, "message": "cmd 必须是字符串"})
            return
        if cmd == "bye":
            self._retire_client(cl)
            return
        if cmd == "ping":
            # UDP hello 可能丢失；每次保活携带当前握手，允许客户端自行恢复。
            self._send_hello(addr)
            self._send_json(addr, {"type": "pong", "t": msg.get("t"), "seq": seq})
            return

        if seq is not None:
            fingerprint = json.dumps(msg, sort_keys=True, separators=(",", ":"))
            if seq in cl.seen:
                if cl.seen[seq] != fingerprint:
                    self._send_json(addr, {"type": "command_result", "cmd": cmd,
                                           "seq": seq, "ok": False,
                                           "message": "seq 已用于其他请求"})
                else:
                    for payload in cl.results.get(seq, []):
                        self._send_json(addr, payload)
                return
            if seq <= cl.highest_seq - SEQ_WINDOW:
                self._send_json(addr, {"type": "command_result", "cmd": cmd,
                                       "seq": seq, "ok": False,
                                       "message": "seq 已超出去重窗口，未执行"})
                return
            cl.highest_seq = max(cl.highest_seq, seq)
            cl.seen[seq] = fingerprint
            for old_seq in list(cl.seen):
                if old_seq <= cl.highest_seq - SEQ_WINDOW:
                    cl.seen.pop(old_seq, None)
                    cl.results.pop(old_seq, None)

        if cmd == "status":
            snap = self.snapshot()
            self._reply_and_cache(cl, seq, snap if snap is not None else
                                  {"type": "error", "message": "暂无遥测"})
            return

        # 网关与插件的机械正方向必须一致。身份登记不能代替插件协议确认。
        zero_manual = (cmd == "manual" and "roll" not in msg
                       and all(type(msg.get(axis, 0.0)) in (int, float)
                               and msg.get(axis, 0.0) == 0.0 for axis in ("yaw", "pitch")))
        safe_request = (cmd in {"stop", "reset_fault"} or zero_manual
                        or (cmd == "set_vision_mode" and msg.get("mode") in {"off", "detect"}))
        if not self._plugin_protocol_compatible and not safe_request:
            self._reply_and_cache(cl, seq, {"type": "command_result", "cmd": cmd,
                                            "ok": False,
                                            "message": "插件尚未确认协议 8 / motion_head_joint_right_positive，禁止运动"})
            return

        if seq is not None and cmd in PASSTHROUGH_CMDS | LOCAL_CMDS:
            if seq < cl.last_control_seq:
                self._reply_and_cache(cl, seq, {"type": "command_result", "cmd": cmd,
                                                "ok": False, "message": "过时指令，未执行"})
                return
            cl.last_control_seq = seq

        if cmd == "set_vision_mode":
            mode = msg.get("mode")
            if mode not in VISION_MODES:
                self._reply_and_cache(cl, seq, {"type": "command_result", "cmd": cmd,
                                                "ok": False,
                                                "message": "mode 必须为 off/detect/auto_lock/manual_track"})
                return
            self._set_vision_mode(mode, force_stop=mode == "off")
            self._reply_and_cache(cl, seq, {"type": "command_result", "cmd": cmd,
                                            "ok": True, "message": ""})
            return

        if cmd == "reset_axis":
            axis = msg.get("axis")
            if not isinstance(axis, str) or axis not in {"yaw", "pitch"}:
                self._reply_and_cache(cl, seq, {"type": "command_result", "cmd": cmd,
                    "ok": False, "message": "axis 必须为 yaw 或 pitch"})
                return
            if self._vision_mode in {"auto_lock", "manual_track"}:
                self._set_vision_mode("off")
            self._record_and_publish(cl, seq, {"cmd": cmd, "axis": axis})
            return

        if cmd in {"track", "manual"}:
            if cmd == "track" and self._vision_mode != "manual_track":
                self._reply_and_cache(cl, seq, {"type": "command_result", "cmd": cmd,
                                                "ok": False,
                                                "message": "请先切换到手动框选模式"})
                return
            try:
                if cmd == "track":
                    box = msg.get("box")
                    if not isinstance(box, (list, tuple)) or len(box) != 4:
                        raise ValueError("选框必须包含四个数值")
                    values = box
                    keys = None
                else:
                    keys = ("yaw", "pitch")
                    if "roll" in msg:
                        raise ValueError("两轴吊舱不支持 roll 输入")
                    values = [msg.get(key, 0.0) for key in keys]
                if any(isinstance(value, bool) or not isinstance(value, (int, float))
                       for value in values):
                    raise ValueError("参数必须是数值")
                values = [float(value) for value in values]
                if not all(math.isfinite(value) for value in values):
                    raise ValueError("参数必须是有限数值")
                if cmd == "track" and (values[2] <= 0 or values[3] <= 0):
                    raise ValueError("选框宽高必须大于零")
                out = {"cmd": cmd}
                if keys:
                    out.update(zip(keys, values))
                    if (any(abs(value) > 1e-9 for value in values)
                            and self._vision_mode in {"auto_lock", "manual_track"}):
                        # 在网关协议层执行人工抢占，保证 GUI 和第三方 CLI 行为一致。
                        self._set_vision_mode("off")
                else:
                    out["box"] = values
                    if "frame_seq" in msg:
                        frame_seq = _as_int(msg.get("frame_seq"))
                        if frame_seq is None or frame_seq < 0:
                            raise ValueError("frame_seq 必须是非负整数")
                        out["frame_seq"] = frame_seq
            except (TypeError, ValueError, OverflowError) as exc:
                self._reply_and_cache(cl, seq, {"type": "command_result", "cmd": cmd,
                                                "ok": False, "message": str(exc)})
                return
            self._record_and_publish(cl, seq, out)
            return

        if cmd in PASSTHROUGH_CMDS:
            if cmd in {"stop", "home", "reset", "reset_fault"}:
                self._set_vision_mode("off")
            self._record_and_publish(cl, seq, {"cmd": cmd})
            return
        self._reply_and_cache(cl, seq, {"type": "command_result", "cmd": cmd,
                                        "ok": False, "message": f"未知指令 {cmd}"})

    def _reply_and_cache(self, cl: _Client, seq, payload: dict):
        """立即回执并缓存；所有带 seq 请求的本地结果均保留关联。"""
        payload = dict(payload, seq=seq)
        text = json.dumps(payload)
        if seq is not None and seq in cl.seen:
            cl.results[seq] = [text]
        self._send_json(cl.addr, text)

    def _record_and_publish(self, cl: _Client, seq, out: dict):
        """使用网关唯一 ID 绑定会话、客户端 seq 和命令。"""
        self._expire_requests(time.monotonic())
        needs_result = out["cmd"] in {"track", "stop", "home", "reset", "reset_axis"}
        if needs_result and len(self.pending_requests) >= MAX_PENDING:
            self._reply_and_cache(cl, seq, {"type": "command_result", "cmd": out["cmd"],
                                            "ok": False, "message": "等待回执队列已满，未执行"})
            return
        request_id = uuid.uuid4().hex
        if needs_result:
            self.pending_requests[request_id] = (cl, seq, out["cmd"], time.monotonic())
        m = StringMsg()
        m.data = json.dumps(dict(out, request_id=request_id))
        try:
            published = self._cmd_pub.publish(m)
        except Exception:
            published = False
        if published is False:
            self.pending_requests.pop(request_id, None)
            self._reply_and_cache(cl, seq, {"type": "command_result", "cmd": out["cmd"],
                                            "ok": False, "message": "发布指令失败"})

    def _forward_command_result(self, data: dict):
        """仅将回执交付给 ID 绑定且仍有效的原始会话。"""
        if not isinstance(data, dict) or not isinstance(data.get("request_id"), str):
            return
        with self.clients_lock:
            self._expire_requests(time.monotonic())
            pending = self.pending_requests.get(data["request_id"])
            if pending is None:
                return
            cl, seq, cmd, _started = pending
            if data.get("cmd") != cmd:
                return
            if self.clients.get(cl.addr) is not cl:
                self.pending_requests.pop(data["request_id"], None)
                return
            if time.monotonic() - cl.last_seen > self.args.client_timeout:
                self._retire_client(cl)
                return
            self.pending_requests.pop(data["request_id"], None)
            payload = dict(data)
            payload.pop("request_id", None)
            self._reply_and_cache(cl, seq, payload)

    def _retire_client(self, cl):
        """取消失效会话的在途请求，短期保留去重结果以防重登记重复执行。"""
        self.clients.pop(cl.addr, None)
        for request_id, (owner, seq, cmd, _started) in list(self.pending_requests.items()):
            if owner is cl:
                self.pending_requests.pop(request_id, None)
                if seq is not None and seq in cl.seen:
                    cl.results[seq] = [json.dumps({"type": "command_result", "cmd": cmd,
                                                  "seq": seq, "ok": False,
                                                  "message": "会话已过期，执行结果未知"})]
        self.retired_clients[cl.addr] = cl

    def _expire_requests(self, now):
        for addr, cl in list(self.retired_clients.items()):
            if now - cl.last_seen > self.args.client_timeout + SESSION_RETENTION:
                self.retired_clients.pop(addr, None)
        for request_id, (cl, seq, cmd, started) in list(self.pending_requests.items()):
            if now - started > RESULT_TIMEOUT:
                self.pending_requests.pop(request_id, None)
                payload = {"type": "command_result", "cmd": cmd, "seq": seq,
                           "ok": False, "message": "插件回执超时，执行结果未知"}
                if self.clients.get(cl.addr) is cl:
                    self._reply_and_cache(cl, seq, payload)

    # ---------------- 广播循环 ----------------
    def _broadcast_telemetry(self, snap=None):
        now = time.monotonic()
        with self.clients_lock:
            self._expire_requests(now)
            for cl in list(self.clients.values()):
                if now - cl.last_seen > self.args.client_timeout:
                    self._retire_client(cl)
            items = list(self.clients.items())
        if snap is None or not self._plugin_protocol_compatible:
            return
        text = json.dumps(snap)
        for addr, _cl in items:
            self._send_json(addr, text)

    def telemetry_thread(self):
        while self._running:
            with self._telemetry_ready:
                self._telemetry_ready.wait_for(
                    lambda: self._telemetry_pending or not self._running, timeout=0.2)
                if not self._running:
                    break
                snap = self._telemetry_pending.popleft() if self._telemetry_pending else None
            try:
                self._broadcast_telemetry(snap)
            except Exception as exc:  # noqa: BLE001 - 广播异常不应终止网关
                print(f"[udp] 遥测广播异常: {exc}", flush=True)

    # ---------------- UDP 接收循环 ----------------
    def udp_rx_loop(self):
        print(f"[udp] 遥测/指令服务 udp://{self.args.udp_host}:"
              f"{self.args.udp_port} (telemetry_hz={self.args.telemetry_hz}, "
              f"client_timeout={self.args.client_timeout}s)", flush=True)
        while self._running:
            try:
                data, addr = self.sock.recvfrom(RECV_BUFFER)
            except socket.timeout:
                continue
            except OSError:
                if self._running:
                    continue
                break
            try:
                self._on_datagram(data, addr)
            except Exception as exc:  # noqa: BLE001 - 单条异常不应终止服务
                print(f"[udp] 处理 {addr} 数据报异常: {exc}", flush=True)

    def close(self):
        self._running = False
        with self._telemetry_ready:
            self._telemetry_ready.notify_all()
        try:
            self.sock.close()
        except OSError:
            pass


def main():
    parser = argparse.ArgumentParser(
        description="云台侧网络网关（gz-transport -> UDP/RTSP）")
    parser.add_argument("--world", default="two_axis_pod_demo")
    parser.add_argument("--gimbal-model", default="two_axis_pod")
    parser.add_argument("--camera-link", default="camera_link")
    parser.add_argument("--camera-sensor", default="camera")
    parser.add_argument("--topic-prefix", default="/two_axis_pod",
                        help="插件 command/telemetry/command_result 的话题前缀")
    parser.add_argument("--image-topic", help="覆盖完整 Gazebo 相机图像话题")
    parser.add_argument("--udp-host", default="0.0.0.0")
    parser.add_argument("--udp-port", type=int, default=8766)
    parser.add_argument("--client-timeout", type=float, default=5.0,
                        help="客户端登记超时（秒，见 docs/control-protocol.md）")
    parser.add_argument("--rtsp-port", type=int, default=8555)
    parser.add_argument("--rtp-port", type=int, default=None,
                        help="内部 RTP 端口；默认自动分配，显式指定时并行实例须不同")
    parser.add_argument("--mount", default="/two_axis_pod", help="RTSP 路径前缀，末尾自动追加 _飞机ID")
    parser.add_argument("--aircraft-id", type=int, default=1, help="非负整数飞机 ID，默认 1；同一 RTSP 服务内必须唯一")
    parser.add_argument("--video-bitrate", type=int, default=8000,
                        help="H.264 码率（kbps）")
    parser.add_argument("--telemetry-config", type=Path, default=DEFAULT_TELEMETRY_CONFIG,
                        help="与插件共用的遥测频率 JSON（hz 默认 50）")
    parser.add_argument("--encoder", choices=["nvenc"], default="nvenc",
                        help="视频编码器：仅支持 NVIDIA NVENC；不可用时拒绝启动")
    parser.add_argument("--vision-config", type=Path, default=DEFAULT_VISION_CONFIG,
                        help="目标检测与多目标跟踪配置 JSON")
    args = parser.parse_args()
    try:
        args.telemetry_hz = load_telemetry_config(args.telemetry_config)
        args.mount = aircraft_mount(args.mount, args.aircraft_id)
        if not 1 <= args.rtsp_port <= 65535:
            raise ValueError("rtsp-port 必须为 1～65535")
        if args.rtp_port is not None and not 1 <= args.rtp_port <= 65535:
            raise ValueError("rtp-port 必须为 1～65535")
        # 启动阶段先验证配置和模型路径；OpenCV/模型前向在首次启用视觉时加载。
        vision_config = load_vision_config(args.vision_config)
        if not vision_config["model_path"].is_file():
            raise ValueError(f"目标检测模型不存在: {vision_config['model_path']}")
    except ValueError as exc:
        parser.error(str(exc))

    try:
        import faulthandler
        faulthandler.register(signal.SIGUSR1, all_threads=True, chain=False)
    except Exception:  # noqa: BLE001
        pass

    def request_shutdown(*_):
        raise KeyboardInterrupt

    # 入口可能从后台 shell 继承忽略 SIGINT；显式恢复有序退出以撤销 RTSP 租约。
    signal.signal(signal.SIGINT, request_shutdown)
    signal.signal(signal.SIGTERM, request_shutdown)
    bridge = GimbalBridge(args)
    threading.Thread(target=bridge.video_thread, daemon=True).start()
    threading.Thread(target=bridge.telemetry_thread, daemon=True).start()
    try:
        bridge.udp_rx_loop()
    except KeyboardInterrupt:
        pass
    finally:
        bridge.close()
        if bridge.video is not None:
            try:
                bridge.video.close()
            except Exception:  # noqa: BLE001
                pass


if __name__ == "__main__":
    main()
