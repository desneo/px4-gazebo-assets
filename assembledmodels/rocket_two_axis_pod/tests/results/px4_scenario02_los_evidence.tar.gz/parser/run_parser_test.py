from pathlib import Path
import hashlib, json, subprocess
root=Path('/tmp/dyt_optional_gyro_validation')
source=Path('/home/aeroarx/zsh/PX4-Autopilot/src/modules/simulation/dyt_udp_bridge/DytUdpBridge.cpp')
text=source.read_text()
parser=text[text.index('namespace\n{'):text.index('\nclass DytUdpBridge')]
header='''#include <cmath>
#include <cstdint>
#include <cstddef>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
'''
harness=r'''
static void check(bool condition, const char *message) {
 if (!condition) throw std::runtime_error(message);
}
static bool parse(const std::string &data, AishengFields &out) {
 return JsonParser(data.data(), data.size()).parse(out);
}
int main() {
 const std::string base=R"({"track_status":1,"pitch_angle":-12.5,"yaw_angle":23.75,"pitch_misalignment":-1.25,"yaw_misalignment":2.5,"tracking_confidence":25.5,"target_confidence":0.8,"pitch_los_rate":19,"yaw_los_rate":-17})";
 auto packet=[&](const std::string &extra) {return base.substr(0,base.size()-1)+","+extra+"}";};
 unsigned passed=0;
 auto run=[&](const std::string &name,const std::function<void()> &test) {
  try {test();++passed;std::cout<<"PASS "<<name<<"\n";}
  catch(const std::exception &error) {std::cerr<<"FAIL "<<name<<": "<<error.what()<<"\n";std::exit(1);}
 };
 run("legacy_nine_fields_zero_gyro",[&] {
  AishengFields f{};check(parse(base,f),"旧九字段包应接受");
  check(f.gyro_pitch_rate==0 && f.gyro_yaw_rate==0,"旧包gyro默认0");
  check(f.pitch_los_rate==19 && f.yaw_los_rate==-17,"旧LOS保真");
 });
 run("new_13_fields_distinct_gyro_and_los",[&] {
  AishengFields f{};check(parse(packet(R"("gyro_pitch_rate":7.25,"gyro_yaw_rate":-8.5,"tracking_gateW":100,"tracking_gateH":80)"),f),"新十三字段包应接受");
  check(f.gyro_pitch_rate==7.25f && f.gyro_yaw_rate==-8.5f,"gyro不应丢弃或反号");
  check(f.pitch_los_rate==19 && f.yaw_los_rate==-17,"gyro不能覆盖LOS");
  check(f.pitch_angle==-12.5f && f.yaw_angle==23.75f && f.track_status==1,"其余字段不变");
 });
 run("pitch_optional_without_yaw",[&] {
  AishengFields f{};check(parse(packet(R"("gyro_pitch_rate":-3.5)"),f),"单独pitch可接受");
  check(f.gyro_pitch_rate==-3.5f && f.gyro_yaw_rate==0,"另一个缺省0");
 });
 run("yaw_optional_without_pitch",[&] {
  AishengFields f{};check(parse(packet(R"("gyro_yaw_rate":4.5)"),f),"单独yaw可接受");
  check(f.gyro_pitch_rate==0 && f.gyro_yaw_rate==4.5f,"另一个缺省0");
 });
 for (const std::string field:{"gyro_pitch_rate","gyro_yaw_rate"}) {
  run(field+"_duplicate_rejected",[&] {
   AishengFields f{};check(!parse(packet("\""+field+"\":1,\""+field+"\":2"),f),"重复已知gyro必须拒绝");
  });
  for (const std::string value:{"null","true","\"3\"","[]","NaN","Infinity","1e99"}) {
   run(field+"_invalid_"+value,[&] {
    AishengFields f{};check(!parse(packet("\""+field+"\":"+value),f),"非法gyro必须拒绝");
   });
  }
 }
 run("zero_los_preserves_nonzero_gyro",[&] {
  auto p=packet(R"("gyro_pitch_rate":-20,"gyro_yaw_rate":20)");
  auto replace=[&](const std::string &a,const std::string &b){p.replace(p.find(a),a.size(),b);};
  replace("\"pitch_los_rate\":19","\"pitch_los_rate\":0");
  replace("\"yaw_los_rate\":-17","\"yaw_los_rate\":0");
  AishengFields f{};check(parse(p,f),"LOS无效报文的0值可接受");
  check(f.pitch_los_rate==0 && f.yaw_los_rate==0 && f.gyro_pitch_rate==-20 && f.gyro_yaw_rate==20,"机械与LOS必须独立");
 });
 run("required_field_still_required",[&] {
  std::string p=base;p.erase(p.find("\"yaw_los_rate\""));p.pop_back();p+="}";
  AishengFields f{};check(!parse(p,f),"旧required字段仍然必需");
 });
 run("unknown_extra_still_compatible",[&] {
  AishengFields f{};check(parse(packet(R"("other":{"optional":[1,true,null]})"),f),"未知扩展字段仍允许");
 });
 std::cout<<"TOTAL "<<passed<<"\n";
}
'''
(root/'parser_test.cpp').write_text(header+parser+harness)
compile_result=subprocess.run(['g++','-std=c++14','-Wall','-Wextra',str(root/'parser_test.cpp'),'-o',str(root/'parser_test')],text=True,capture_output=True)
(root/'compile.log').write_text(compile_result.stdout+compile_result.stderr)
if compile_result.returncode:raise SystemExit(compile_result.stderr)
result=subprocess.run([str(root/'parser_test')],text=True,capture_output=True)
(root/'parser.log').write_text(result.stdout+result.stderr)
report=dict(source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),exit_code=result.returncode,passed=[line[5:] for line in result.stdout.splitlines() if line.startswith('PASS ')])
report['case_count']=len(report['passed'])
(root/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(result.stdout,result.stderr,end='')
raise SystemExit(result.returncode)
